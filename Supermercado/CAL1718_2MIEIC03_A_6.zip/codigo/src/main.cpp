
#include <cstdio>
#include <fstream>
#include <iostream>
#include <sstream>
#include <unistd.h>
#include <vector>
#include <iostream>
#include <cstdlib>
#include "Menu.h"


using namespace std;

int main() {
	new Menu();
	getchar();
	return 0;
}
