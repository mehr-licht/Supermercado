
#include "Road.h"

long long Road::getId(){
	return this->id;
}


bool Road::isTwoWay() {
	return this->two_way;
}

