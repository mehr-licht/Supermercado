

#include "RoadConnection.h"

long long RoadConnection::getRoadId(){
	return this->roadId;
}

long long RoadConnection::getNode1() {
	return this->node1;
}

long long RoadConnection::getNode2() {
	return this->node2;
}


